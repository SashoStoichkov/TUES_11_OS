#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <pwd.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

char directories[FILENAME_MAX][FILENAME_MAX];

typedef struct flags_t {
    int l;
    int a;
    int r;
} flags_t;

void get_dirs(char *directory, int index, flags_t flags) {
    DIR *dir = opendir(directory);
    struct dirent *entry;

    int i = index;

    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_DIR) {
            char path[1024];
            if (strcmp(entry->d_name, ".") != 0 && strcmp(entry->d_name, "..") != 0) {
                if (flags.a == 1) {
                    snprintf(path, sizeof(path), "%s/%s", directory, entry->d_name);
                    strcpy(directories[i], path);
                    // printf("%s\n", directories[i]);
                    get_dirs(path, i+1, flags);
                } else {
                    if (entry->d_name[0] != '.') {
                        snprintf(path, sizeof(path), "%s/%s", directory, entry->d_name);
                        strcpy(directories[i], path);
                        // printf("%s\n", directories[i]);
                        get_dirs(path, i+1, flags);
                    }
                }
            }
        }
    }

    closedir(dir);
}

void print_file_permissions(mode_t mode) {
    putchar((mode & S_IRUSR) ? 'r' : '-');
    putchar((mode & S_IWUSR) ? 'w' : '-');
    putchar((mode & S_IXUSR) ? 'x' : '-');
    putchar((mode & S_IRGRP) ? 'r' : '-');
    putchar((mode & S_IWGRP) ? 'w' : '-');
    putchar((mode & S_IXGRP) ? 'x' : '-');
    putchar((mode & S_IROTH) ? 'r' : '-');
    putchar((mode & S_IWOTH) ? 'w' : '-');
    putchar((mode & S_IXOTH) ? 'x' : '-');
}
void print_file_type(mode_t mode) {
    if (S_ISREG(mode)) putchar('-');
    else if (S_ISDIR(mode)) putchar('d');
    else if (S_ISLNK(mode)) putchar('l');
    else if (S_ISCHR(mode)) putchar('c');
    else if (S_ISBLK(mode)) putchar('b');
    else if (S_ISSOCK(mode)) putchar('s');
    else if (S_ISFIFO(mode)) putchar('f');
}

long get_long_file_info(struct stat st) {
    print_file_type(st.st_mode);
    print_file_permissions(st.st_mode);

    printf(" %ld", st.st_nlink);

    struct passwd *pwd_user;
    pwd_user = getpwuid(st.st_uid);
    printf(" %s", pwd_user->pw_name);

    struct passwd *pwd_group;
    pwd_group = getpwuid(st.st_gid);
    printf(" %s", pwd_group->pw_name);

    printf(" %ld", st.st_size);

    time_t now;
    time(&now);

    double seconds_difference = difftime(now, mktime(localtime(&(st.st_mtime))));

    char date[20];

    if (seconds_difference / 2628002.88 > 6){
        strftime(date, 20, "%b %e %Y", localtime(&(st.st_mtime)));
    } else {
        strftime(date, 20, "%b %e %H:%M", localtime(&(st.st_mtime)));
    }

    printf(" %s", date);

    return st.st_blocks;
}

long get_info(char *path, char *filename, flags_t flags) {
    long total = 0;
    struct stat st;

    if (stat(path, &st) == 0) {
        if (flags.l == 1) {
            if (flags.a == 1) {
                if ((strcmp(filename, ".") != 0) && (strcmp(filename, "..") != 0)) {
                    total = get_long_file_info(st);
                    printf(" %s\n", filename);
                }
            } else {
                if (filename[0] != '.') {
                    total = get_long_file_info(st);
                    printf(" %s\n", filename);
                }
            }
        } else {
            if (flags.a == 1) {
                if ((strcmp(filename, ".") != 0) && (strcmp(filename, "..") != 0)) {
                    print_file_type(st.st_mode);
                    printf(" %s\n", filename);
                }
            } else {
                if (filename[0] != '.') {
                    print_file_type(st.st_mode);
                    printf(" %s\n", filename);
                }
            }
        }
    } else {
        perror("stat");
    }

    return total;
}

void ls(char *path, char *filename, flags_t flags) {
    struct stat s;
    stat(path, &s);

    if (S_ISDIR(s.st_mode)) {
        DIR *dir = opendir(path);
        struct dirent *entry;

        long total = 0;

        while ((entry = readdir(dir))) {
            char full_path[FILENAME_MAX];
            strcpy(full_path, path);
            strcat(full_path, "/");
            strcat(full_path, entry->d_name);

            total += get_info(full_path, entry->d_name, flags);
        }

        if (flags.l == 1) {
            printf("total %ld\n", total / 2);
        }

        closedir(dir);
    } else {
        get_info(path, filename, flags);
    }
}

int main(int argc, char *const argv[]) {
    flags_t flags;
    flags.l = 0;
    flags.a = 0;
    flags.r = 0;

    int opt;
    while ((opt = getopt(argc, argv, "lAR")) != -1) {
        switch (opt) {
            case 'l': flags.l = 1; break;
            case 'A': flags.a = 1; break;
            case 'R': flags.r = 1; break;
            default: return -1;
        }
    }

    get_dirs(".", 0, flags);

    if (argc == optind) {
        ls(".", "", flags);
    } else {
        for (int i = optind; i < argc; i++) {
            struct stat s;
            stat(argv[i], &s);

            if (i != optind) printf("\n");
            if (i >= optind && S_ISDIR(s.st_mode) && argc != optind+1) {
                printf("%s:\n", argv[i]);
            }
            ls(argv[i], argv[i], flags);
        }
    }

    return 0;
}